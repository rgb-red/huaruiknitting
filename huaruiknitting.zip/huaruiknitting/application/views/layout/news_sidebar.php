<div class="left_news">
    <h3 class="left_h3">
        <span><?=CONFIG($this->LAN)["title_4"]?></span>
    </h3>
    <ul class="left_news">
        <li>
            <a href="/home/news_detail" title="为生活提供更舒适、更健康、更美的产品">为生活提供更舒适、更健康、更美的...</a></li>
        <li>
            <a href="/home/news_detail" title="华瑞是一个富有激情和理想的团队">华瑞是一个富有激情和理想的团队</a></li>
        <li>
            <a href="/home/news_detail" title="华瑞针织实业有限公司">华瑞针织实业有限公司</a></li>
        <li>
            <a href="/home/news_detail" title="“勇于实践，不断创新，客户满意，信誉第一”">“勇于实践，不断创新，客户满意...</a></li>
        <li>
            <a href="/home/news_detail" title="移动时代，如何科学的运用品牌？">移动时代，如何科学的运用品牌？</a></li>
    </ul>
</div>