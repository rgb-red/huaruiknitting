<div class="left_column">
    <ul class="left_nav_ul" id="firstpane">
        <li><a href="javascript:;" class="biglink <?php if($sort == 1):?>left_active<?php endif;?>">保暖衣系列</a></li>
        <li><a href="javascript:;" class="biglink <?php if($sort == 2):?>left_active<?php endif;?>">内衣系列</a></li>
        <li><a href="javascript:;" class="biglink <?php if($sort == 3):?>left_active<?php endif;?>">泳衣系列</a></li>
        <li><a href="javascript:;" class="biglink <?php if($sort == 4):?>left_active<?php endif;?>">运动系列</a></li>
        <ul class="left_snav_ul menu_body"></ul>
    </ul>
</div>