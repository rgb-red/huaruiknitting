<div class="right_contents">
    <?=CONFIG($this->LAN)["about_us_article"]?>
</div>