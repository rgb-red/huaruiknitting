<div class="right_contents">
    <?=CONFIG($this->LAN)["ceo_speech_article"]?>
</div>